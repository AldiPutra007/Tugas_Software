package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.Locale;

// 3 Baris ini WAJIB ADA untuk menjalankan Retrofit
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MBankingActivity extends AppCompatActivity {

    private TextView tvTotal;
    private MaterialButton btnSelesai;

    private double totalHarga;
    private String metodePembayaran = "MBANKING"; // Mengikuti format di database

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mbanking);

        tvTotal = findViewById(R.id.tvTotal);
        btnSelesai = findViewById(R.id.btnSelesai);

        // ambil data dari intent
        totalHarga = getIntent().getDoubleExtra("TOTAL_HARGA", 0);

        // format rupiah
        Locale localeID = new Locale("in", "ID");
        NumberFormat rupiah = NumberFormat.getCurrencyInstance(localeID);

        tvTotal.setText(rupiah.format(totalHarga));

        btnSelesai.setOnClickListener(v -> {
            // Panggil fungsi untuk menyimpan ke database melalui API
            simpanTransaksiMBanking(totalHarga);
        });
    }

    private void simpanTransaksiMBanking(double total) {
        // Matikan tombol sementara agar tidak diklik berkali-kali (double submit)
        btnSelesai.setEnabled(false);
        btnSelesai.setText("Memproses...");

        // INI KODE ASLI RETROFIT YANG SUDAH DINYALAKAN:
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ResponseModel> call = apiService.simpanTransaksi(total, metodePembayaran);

        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                btnSelesai.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    String status = response.body().getStatus();

                    if (status.equals("sukses")) {
                        // JIKA BERHASIL MASUK DATABASE POSTGRESQL, BARU PINDAH HALAMAN
                        pindahKeHalamanBerhasil();
                    } else {
                        Toast.makeText(MBankingActivity.this, response.body().getPesan(), Toast.LENGTH_SHORT).show();
                        btnSelesai.setText("Selesai");
                    }
                } else {
                    Toast.makeText(MBankingActivity.this, "Gagal terhubung ke server PHP", Toast.LENGTH_SHORT).show();
                    btnSelesai.setText("Selesai");
                }
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                btnSelesai.setEnabled(true);
                Toast.makeText(MBankingActivity.this, "Error koneksi: " + t.getMessage(), Toast.LENGTH_LONG).show();
                btnSelesai.setText("Selesai");
            }
        });
    }

    // Fungsi ini dipanggil HANYA jika data sudah aman masuk ke database
    private void pindahKeHalamanBerhasil() {

        // Hapus keranjang setelah dipastikan transaksi berhasil
        KeranjangManager.keranjang.clear();

        Intent intent = new Intent(MBankingActivity.this, TransaksiBerhasilActivity.class);
        intent.putExtra("TOTAL_HARGA", totalHarga);
        intent.putExtra("METODE", metodePembayaran);

        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }
}