package com.example.cloudkasir;

public class Riwayat {
    private String id;
    private String tanggal;
    private double totalPembelian;
    private String metodePembayaran;

    public Riwayat(String id, String tanggal, double totalPembelian, String metodePembayaran) {
        this.id = id;
        this.tanggal = tanggal;
        this.totalPembelian = totalPembelian;
        this.metodePembayaran = metodePembayaran;
    }

    public String getId() { return id; }
    public String getTanggal() { return tanggal; }
    public double getTotalPembelian() { return totalPembelian; }
    public String getMetodePembayaran() { return metodePembayaran; }
}