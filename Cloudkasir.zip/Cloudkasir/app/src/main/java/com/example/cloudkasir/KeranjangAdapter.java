package com.example.cloudkasir;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView; // Pastikan ini di-import
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide; // Pastikan ini di-import
import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class KeranjangAdapter extends RecyclerView.Adapter<KeranjangAdapter.ViewHolder> {

    private List<KeranjangItem> listKeranjang;
    private OnCartChangeListener listener;

    public interface OnCartChangeListener {
        void onCartChanged();
    }

    public KeranjangAdapter(List<KeranjangItem> listKeranjang, OnCartChangeListener listener) {
        this.listKeranjang = listKeranjang;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_keranjang, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        KeranjangItem item = listKeranjang.get(position);

        holder.tvProductName.setText(item.getNamaProduk());
        holder.tvQty.setText(String.valueOf(item.getJumlah()));

        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);

        holder.tvUnitPrice.setText(formatRupiah.format(item.getHarga()));
        holder.tvSubtotalPrice.setText(formatRupiah.format(item.getHarga() * item.getJumlah()));

        // TAMBAHAN: Tampilkan Gambar Menggunakan Glide
        Glide.with(holder.itemView.getContext())
                .load(item.getFotoUrl())
                .placeholder(R.mipmap.ic_launcher) // Gambar sementara jika loading
                .error(R.mipmap.ic_launcher)       // Gambar jika URL error/kosong
                .into(holder.imgProduct);

        holder.btnPlus.setOnClickListener(v -> {
            item.setJumlah(item.getJumlah() + 1);
            notifyItemChanged(position);
            listener.onCartChanged();
        });

        holder.btnMinus.setOnClickListener(v -> {
            if (item.getJumlah() > 1) {
                item.setJumlah(item.getJumlah() - 1);
                notifyItemChanged(position);
            } else {
                listKeranjang.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, listKeranjang.size());
            }
            listener.onCartChanged();
        });
    }

    @Override
    public int getItemCount() {
        return listKeranjang.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvProductName, tvUnitPrice, tvSubtotalPrice, tvQty;
        ImageButton btnMinus, btnPlus;
        ImageView imgProduct; // Tambahan deklarasi ImageView

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvProductName = itemView.findViewById(R.id.tvProductName);
            tvUnitPrice = itemView.findViewById(R.id.tvUnitPrice);
            tvSubtotalPrice = itemView.findViewById(R.id.tvSubtotalPrice);
            tvQty = itemView.findViewById(R.id.tvQty);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);

            // TAMBAHAN: Hubungkan ID komponen gambar dari XML Anda
            imgProduct = itemView.findViewById(R.id.imgProduct);
        }
    }
}