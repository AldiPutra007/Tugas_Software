package com.example.cloudkasir;

import com.google.gson.annotations.SerializedName;

public class ResponseModel {

    // @SerializedName memastikan nama variabel di Java cocok
    // dengan key JSON ("status" dan "pesan") yang dikirim dari PHP
    @SerializedName("status")
    private String status;

    @SerializedName("pesan")
    private String pesan;

    // --- Getter ---
    // Fungsi ini digunakan untuk mengambil nilainya di dalam Activity

    public String getStatus() {
        return status;
    }

    public String getPesan() {
        return pesan;
    }

    // --- Setter ---
    // (Opsional, tapi disarankan ada sebagai standar penulisan model)

    public void setStatus(String status) {
        this.status = status;
    }

    public void setPesan(String pesan) {
        this.pesan = pesan;
    }
}