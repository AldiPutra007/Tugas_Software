package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ProdukActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ProdukAdapter adapter;
    private ArrayList<Produk> produkList;

    private static final String URL_TAMPIL =
            "http://10.35.5.88/cloudkasir/tampil_produk.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produk);

        recyclerView = findViewById(R.id.rvProduk);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        produkList = new ArrayList<>();

        // Tombol Tambah Barang
        ImageButton btnTambah = findViewById(R.id.btnTambahBarang);
        btnTambah.setOnClickListener(v -> {
            Intent intent = new Intent(ProdukActivity.this, TambahBarangActivity.class);
            startActivity(intent);
        });

        // ==================== LOGIKA NAVIGASI BAWAH ====================
        TextView navDashboard = findViewById(R.id.navDashboard);
        TextView navTransaksi = findViewById(R.id.navTransaksi);
        TextView navBelanja = findViewById(R.id.navBelanja);
        TextView navProduk = findViewById(R.id.navProduk);
        TextView navLainnya = findViewById(R.id.navLainnya);

        // Warnai menu Produk menjadi biru sebagai penanda halaman aktif
        navProduk.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
        // Warnai sisanya menjadi abu-abu
        navDashboard.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navTransaksi.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navBelanja.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navLainnya.setTextColor(getResources().getColor(android.R.color.darker_gray));

        navDashboard.setOnClickListener(v -> {
            startActivity(new Intent(ProdukActivity.this, DashboardActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });

        navTransaksi.setOnClickListener(v -> {
            startActivity(new Intent(ProdukActivity.this, RiwayatTransaksiActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });

        // Aksi klik ke halaman Belanja (BARU DITAMBAHKAN)
        navBelanja.setOnClickListener(v -> {
            startActivity(new Intent(ProdukActivity.this, TransaksiActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });

        navLainnya.setOnClickListener(v -> {
            startActivity(new Intent(ProdukActivity.this, PengaturanActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });
        // ===============================================================

        muatDataProduk();
    }

    private void muatDataProduk() {

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                URL_TAMPIL,
                null,

                response -> {

                    produkList.clear();

                    try {

                        for (int i = 0; i < response.length(); i++) {

                            JSONObject obj = response.getJSONObject(i);

                            String id = obj.getString("id");
                            String nama = obj.getString("nama");
                            int harga = obj.getInt("harga");
                            int stok = obj.getInt("stok");
                            String foto = obj.getString("foto");

                            produkList.add(new Produk(id, nama, harga, stok, foto));
                        }

                        adapter = new ProdukAdapter(ProdukActivity.this, produkList);
                        recyclerView.setAdapter(adapter);

                    } catch (JSONException e) {

                        Toast.makeText(ProdukActivity.this, "Gagal memproses data", Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }
                },

                error -> Toast.makeText(ProdukActivity.this, "Gagal terhubung ke server", Toast.LENGTH_SHORT).show()
        );

        RequestQueue queue = Volley.newRequestQueue(this);
        queue.add(request);
    }

    @Override
    protected void onResume() {
        super.onResume();
        muatDataProduk();
    }
}