package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class RiwayatTransaksiActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RiwayatAdapter adapter;
    private ArrayList<Riwayat> riwayatList;

    // Pastikan IP ini selalu sesuai dengan IPv4 laptop Anda saat ini
    private static final String URL_RIWAYAT = "http://10.35.5.88/cloudkasir/tampil_riwayat.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_riwayat_transaksi);

        // 1. Inisialisasi RecyclerView
        recyclerView = findViewById(R.id.rvRiwayat);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        riwayatList = new ArrayList<>();

        // Jalankan fungsi untuk mengambil data riwayat dari database
        muatDataRiwayat();

        // 2. Setup Navigasi Bawah (Bottom Navigation)
        TextView navDashboard = findViewById(R.id.navDashboard);
        TextView navTransaksi = findViewById(R.id.navTransaksi);
        TextView navBelanja = findViewById(R.id.navBelanja);
        TextView navProduk = findViewById(R.id.navProduk);
        TextView navLainnya = findViewById(R.id.navLainnya);

        // Warnai menu Transaksi menjadi biru sebagai penanda halaman aktif
        navTransaksi.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
        // Warnai sisanya menjadi abu-abu
        navDashboard.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navBelanja.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navProduk.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navLainnya.setTextColor(getResources().getColor(android.R.color.darker_gray));

        // Aksi klik navigasi
        navDashboard.setOnClickListener(v -> {
            Intent intent = new Intent(RiwayatTransaksiActivity.this, DashboardActivity.class);
            // Membersihkan tumpukan halaman agar tidak memakan RAM
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        });

        // Aksi klik ke halaman Belanja (BARU DITAMBAHKAN)
        navBelanja.setOnClickListener(v -> {
            Intent intent = new Intent(RiwayatTransaksiActivity.this, TransaksiActivity.class);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        });

        navProduk.setOnClickListener(v -> {
            startActivity(new Intent(RiwayatTransaksiActivity.this, ProdukActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });

        navLainnya.setOnClickListener(v -> {
            startActivity(new Intent(RiwayatTransaksiActivity.this, PengaturanActivity.class));
            finish();
            overridePendingTransition(0, 0);
        });
    }

    // 3. Fungsi mengambil data JSON dari server PHP menggunakan Volley
    private void muatDataRiwayat() {
        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, URL_RIWAYAT, null,
                response -> {
                    try {
                        // Kosongkan list sebelum diisi data baru agar tidak duplikat
                        riwayatList.clear();

                        for (int i = 0; i < response.length(); i++) {
                            JSONObject obj = response.getJSONObject(i);

                            // PENTING: Key JSON ("id", "tanggal", "total_pembelian", "metode_pembayaran")
                            // wajib sama persis dengan nama kolom di tabel PostgreSQL
                            String id = obj.getString("id");
                            String tanggal = obj.getString("tanggal");
                            double totalPembelian = obj.getDouble("total_pembelian");
                            String metodePembayaran = obj.getString("metode_pembayaran");

                            // Masukkan data yang didapat ke dalam model Riwayat
                            riwayatList.add(new Riwayat(id, tanggal, totalPembelian, metodePembayaran));
                        }

                        // Pasang data ke adapter lalu tampilkan di RecyclerView
                        adapter = new RiwayatAdapter(RiwayatTransaksiActivity.this, riwayatList);
                        recyclerView.setAdapter(adapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(RiwayatTransaksiActivity.this, "Gagal memproses data JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(RiwayatTransaksiActivity.this, "Gagal terhubung ke server. Cek IP atau koneksi Anda.", Toast.LENGTH_LONG).show();
                }
        );

        // Tambahkan antrean request ke Volley
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }
}