package com.example.cloudkasir; // Sesuaikan dengan nama package Anda

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegisterLink, tvForgotPassword, tvTabLogin, tvTabDaftar;

    // URL untuk file login.php di server lokal kamu (gunakan 10.0.2.2 untuk emulator)
    private static final String URL_LOGIN = "http://10.35.5.88/cloudkasir/login.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1. Inisialisasi Views
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegisterLink = findViewById(R.id.tvRegisterLink);
        tvForgotPassword = findViewById(R.id.tvForgotPassword);
        tvTabLogin = findViewById(R.id.tvTabLogin);
        tvTabDaftar = findViewById(R.id.tvTabDaftar);

        // 2. Mewarnai kata "Daftar" pada teks bawah menjadi biru dan bold
        String registerText = "Belum punya akun? Daftar";
        SpannableString spannable = new SpannableString(registerText);
        spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#0C5DD6")), 18, 24, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), 18, 24, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvRegisterLink.setText(spannable);

        // 3. Aksi Tombol Login (MENGGUNAKAN VOLLEY)
        btnLogin.setOnClickListener(v -> {
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Mohon lengkapi email dan password", Toast.LENGTH_SHORT).show();
            } else {
                // Memanggil fungsi login ke database
                loginUser(email, password);
            }
        });

        // 4. Aksi Lupa Password
        tvForgotPassword.setOnClickListener(v -> {
            Toast.makeText(LoginActivity.this, "Halaman lupa password belum tersedia", Toast.LENGTH_SHORT).show();
        });

        // 5. Aksi Klik Teks Register Bawah
        tvRegisterLink.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });

        // 6. Aksi Tab Atas
        tvTabDaftar.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
            finish();
        });
    }

    // Fungsi untuk mengirim data login ke PHP menggunakan Volley
    private void loginUser(final String email, final String password) {
        Toast.makeText(this, "Mencoba masuk...", Toast.LENGTH_SHORT).show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_LOGIN,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");
                        String message = jsonObject.getString("message");

                        if (status.equals("success")) {
                            Toast.makeText(LoginActivity.this, "Login Berhasil!", Toast.LENGTH_SHORT).show();

                            // Jika berhasil, arahkan ke Dashboard
                            Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
                            startActivity(intent);

                            // Tutup halaman login agar user tidak bisa menekan tombol back untuk kembali ke sini
                            finish();
                        } else {
                            // Tampilkan pesan error dari PHP (misal: "Password salah!" atau "Email tidak ditemukan!")
                            Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(LoginActivity.this, "Error format JSON: " + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(LoginActivity.this, "Gagal koneksi ke server! Cek jaringan.", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Data ini yang akan ditangkap oleh $_POST di file login.php
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}