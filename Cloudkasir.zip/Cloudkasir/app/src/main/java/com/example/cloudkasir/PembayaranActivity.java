package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.Locale;

// Import Retrofit
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembayaranActivity extends AppCompatActivity {

    private TextView tvTotalAmount;
    private MaterialButton btnBayarAkhir;
    private LinearLayout btnMethodTunai, btnMethodQRIS, btnMethodBank;

    private String metodePembayaran = "Tunai"; // Default
    private double totalHarga = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran);

        // Inisialisasi View
        tvTotalAmount = findViewById(R.id.tvTotalAmount);
        btnBayarAkhir = findViewById(R.id.btnBayarAkhir);
        btnMethodTunai = findViewById(R.id.btnMethodTunai);
        btnMethodQRIS = findViewById(R.id.btnMethodQRIS);
        btnMethodBank = findViewById(R.id.btnMethodBank);

        totalHarga = getIntent().getDoubleExtra("TOTAL_HARGA", 0);

        // Format Rupiah
        Locale localeID = new Locale("in", "ID");
        NumberFormat rupiah = NumberFormat.getCurrencyInstance(localeID);
        tvTotalAmount.setText(rupiah.format(totalHarga));
        btnBayarAkhir.setText("Bayar " + rupiah.format(totalHarga));

        // Logic Pemilihan Metode
        pilihMetode("Tunai");
        btnMethodTunai.setOnClickListener(v -> { metodePembayaran = "Tunai"; pilihMetode("Tunai"); });
        btnMethodQRIS.setOnClickListener(v -> { metodePembayaran = "QRIS"; pilihMetode("QRIS"); });
        btnMethodBank.setOnClickListener(v -> { metodePembayaran = "MBANKING"; pilihMetode("MBANKING"); });

        // Tombol Bayar
        btnBayarAkhir.setOnClickListener(v -> prosesPembayaran());
    }

    private void prosesPembayaran() {
        if (metodePembayaran.equals("Tunai")) {
            // Langsung simpan ke database
            simpanTransaksi(totalHarga, "Tunai");
        } else {
            // Arahkan ke activity QRIS atau M-Banking
            Intent intent = (metodePembayaran.equals("QRIS")) ?
                    new Intent(this, QrisActivity.class) :
                    new Intent(this, MBankingActivity.class);

            intent.putExtra("TOTAL_HARGA", totalHarga);
            startActivity(intent);
        }
    }

    private void simpanTransaksi(double total, String metode) {
        btnBayarAkhir.setEnabled(false);
        btnBayarAkhir.setText("Memproses...");

        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ResponseModel> call = apiService.simpanTransaksi(total, metode);

        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                btnBayarAkhir.setEnabled(true);
                if (response.isSuccessful() && response.body() != null && response.body().getStatus().equals("sukses")) {
                    KeranjangManager.keranjang.clear();
                    Intent intent = new Intent(PembayaranActivity.this, TransaksiBerhasilActivity.class);
                    intent.putExtra("TOTAL_HARGA", total);
                    intent.putExtra("METODE", metode);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(PembayaranActivity.this, "Gagal simpan ke database", Toast.LENGTH_SHORT).show();
                    btnBayarAkhir.setText("Bayar");
                }
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                btnBayarAkhir.setEnabled(true);
                Toast.makeText(PembayaranActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                btnBayarAkhir.setText("Bayar");
            }
        });
    }

    private void pilihMetode(String metode) {
        btnMethodTunai.setBackgroundResource(R.drawable.bg_metode_biasa);
        btnMethodQRIS.setBackgroundResource(R.drawable.bg_metode_biasa);
        btnMethodBank.setBackgroundResource(R.drawable.bg_metode_biasa);

        if (metode.equals("Tunai")) btnMethodTunai.setBackgroundResource(R.drawable.bg_metode_dipilih);
        else if (metode.equals("QRIS")) btnMethodQRIS.setBackgroundResource(R.drawable.bg_metode_dipilih);
        else btnMethodBank.setBackgroundResource(R.drawable.bg_metode_dipilih);
    }
}