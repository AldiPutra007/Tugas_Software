package com.example.cloudkasir;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Locale;

public class RiwayatAdapter extends RecyclerView.Adapter<RiwayatAdapter.RiwayatViewHolder> {

    private Context context;
    private ArrayList<Riwayat> riwayatList;

    // Constructor
    public RiwayatAdapter(Context context, ArrayList<Riwayat> riwayatList) {
        this.context = context;
        this.riwayatList = riwayatList;
    }

    @NonNull
    @Override
    public RiwayatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Menghubungkan adapter dengan desain layout item_riwayat.xml
        View view = LayoutInflater.from(context).inflate(R.layout.item_riwayat, parent, false);
        return new RiwayatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RiwayatViewHolder holder, int position) {
        // Mengambil data berdasarkan posisi (urutan) di list
        Riwayat riwayat = riwayatList.get(position);

        // Menampilkan ID/Nota dan Tanggal
        holder.txtId.setText("Nota #" + riwayat.getId());
        holder.txtTanggal.setText(riwayat.getTanggal());

        // Mengubah format angka total harga menjadi format Rupiah (Rp)
        Locale localeID = new Locale("in", "ID");
        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);
        holder.txtTotal.setText(formatRupiah.format(riwayat.getTotalPembelian()));
    }

    @Override
    public int getItemCount() {
        // Mengembalikan jumlah total data yang ada di list
        return riwayatList.size();
    }

    // Class ViewHolder untuk mendefinisikan elemen-elemen di XML
    public static class RiwayatViewHolder extends RecyclerView.ViewHolder {
        TextView txtId, txtTotal, txtTanggal;

        public RiwayatViewHolder(@NonNull View itemView) {
            super(itemView);
            // ID di sini sudah disamakan persis dengan yang ada di item_riwayat.xml
            txtId = itemView.findViewById(R.id.txtIdTransaksi);
            txtTotal = itemView.findViewById(R.id.txtTotalHarga);
            txtTanggal = itemView.findViewById(R.id.txtTanggal);
        }
    }
}