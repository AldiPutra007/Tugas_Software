package com.example.cloudkasir;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.textfield.TextInputEditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private TextInputEditText etName, etEmail, etPassword;
    private Button btnRegister;
    private TextView tvLoginLink, tvTabLogin;

    // Ganti URL ini sesuai dengan lokasi file register.php kamu di folder htdocs
    // Gunakan 10.0.2.2 jika menggunakan Emulator Android Studio
    private static final String URL_REGISTER = "http://10.35.5.88/cloudkasir/register.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        // 1. Inisialisasi Views
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvLoginLink = findViewById(R.id.tvLoginLink);
        tvTabLogin = findViewById(R.id.tvTabLogin);

        // 2. Mewarnai kata "Login"
        String loginText = "Sudah punya akun? Login";
        SpannableString spannable = new SpannableString(loginText);
        spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#0C5DD6")), 18, 23, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        spannable.setSpan(new StyleSpan(android.graphics.Typeface.BOLD), 18, 23, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        tvLoginLink.setText(spannable);

        // 3. Aksi Tombol Daftar (MENGGUNAKAN VOLLEY)
        btnRegister.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String email = etEmail.getText().toString().trim();
            String password = etPassword.getText().toString().trim();

            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Mohon lengkapi semua data", Toast.LENGTH_SHORT).show();
            } else if (password.length() < 6) {
                Toast.makeText(RegisterActivity.this, "Password minimal 6 karakter", Toast.LENGTH_SHORT).show();
            } else {
                // Panggil fungsi untuk mendaftar ke database
                registerUser(name, email, password);
            }
        });

        tvLoginLink.setOnClickListener(v -> finish());
        tvTabLogin.setOnClickListener(v -> finish());
    }

    // Fungsi untuk mengirim data ke PHP menggunakan Volley
    private void registerUser(final String name, final String email, final String password) {
        Toast.makeText(this, "Memproses pendaftaran...", Toast.LENGTH_SHORT).show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_REGISTER,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");
                        String message = jsonObject.getString("message");

                        if (status.equals("success")) {
                            Toast.makeText(RegisterActivity.this, "Pendaftaran Berhasil!", Toast.LENGTH_SHORT).show();

                            // Sesuai alur logika: Setelah sukses daftar, arahkan user ke halaman Login
                            // Agar mereka mencoba masuk dengan akun yang baru saja dibuat
                            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            // Menampilkan pesan error dari PHP (misal: Email sudah terdaftar)
                            Toast.makeText(RegisterActivity.this, message, Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(RegisterActivity.this, "Error format JSON: " + e.toString(), Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(RegisterActivity.this, "Gagal koneksi ke server!", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Data ini yang akan ditangkap oleh $_POST di file PHP
                Map<String, String> params = new HashMap<>();
                params.put("nama", name);
                params.put("email", email);
                params.put("password", password);
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}