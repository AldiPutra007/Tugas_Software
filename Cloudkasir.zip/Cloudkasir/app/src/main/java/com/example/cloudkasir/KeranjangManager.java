package com.example.cloudkasir;

import java.util.ArrayList;

public class KeranjangManager {

    public static ArrayList<KeranjangItem> keranjang =
            new ArrayList<>();

}