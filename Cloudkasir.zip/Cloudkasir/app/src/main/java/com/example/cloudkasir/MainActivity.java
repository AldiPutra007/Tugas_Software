package com.example.cloudkasir; // Sesuaikan dengan nama package Anda

import android.graphics.Color;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Inisialisasi View
        TextView tvAppName = findViewById(R.id.tvAppName);
        Button btnMulai = findViewById(R.id.btnMulai);

        // 2. Membuat teks "CloudKasir" menjadi dua warna
        String text = "CloudKasir";
        SpannableString spannable = new SpannableString(text);

        // Mewarnai kata "Cloud" (index 0 sampai 5)
        spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#1B2236")), 0, 5, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        // Mewarnai kata "Kasir" (index 5 sampai 10)
        spannable.setSpan(new ForegroundColorSpan(Color.parseColor("#0C5DD6")), 5, 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        tvAppName.setText(spannable);

        // 3. Menambahkan aksi pada tombol
        btnMulai.setOnClickListener(v -> {
            // Berpindah dari MainActivity ke LoginActivity
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
            // Opsional: tambahkan finish(); jika tidak ingin user bisa kembali ke halaman onboarding saat menekan tombol back
        });
    }
}