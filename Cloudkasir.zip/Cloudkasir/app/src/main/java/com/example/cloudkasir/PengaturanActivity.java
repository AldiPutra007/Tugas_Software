package com.example.cloudkasir; // Sesuaikan dengan package milikmu!

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PengaturanActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pengaturan);

        // ==================== LOGIKA NAVIGASI BAWAH (NAVBAR) ====================
        TextView navDashboard = findViewById(R.id.navDashboard);
        TextView navTransaksi = findViewById(R.id.navTransaksi);
        TextView navBelanja = findViewById(R.id.navBelanja);
        TextView navProduk = findViewById(R.id.navProduk);
        TextView navLainnya = findViewById(R.id.navLainnya);

        // Warnai menu Lainnya menjadi biru sebagai penanda halaman aktif saat ini
        navLainnya.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));
        // Warnai sisanya menjadi abu-abu
        navDashboard.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navTransaksi.setTextColor(getResources().getColor(android.R.color.darker_gray));
        navBelanja.setTextColor(getResources().getColor(android.R.color.darker_gray)); // Tambahan pewarnaan
        navProduk.setTextColor(getResources().getColor(android.R.color.darker_gray));

        // Aksi klik kembali ke Dashboard
        navDashboard.setOnClickListener(v -> {
            Intent intent = new Intent(PengaturanActivity.this, DashboardActivity.class);
            // Kembali ke dashboard tanpa membuat tumpukan aktivitas baru
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        });

        // Aksi klik ke halaman Riwayat Transaksi
        navTransaksi.setOnClickListener(v -> {
            Intent intent = new Intent(PengaturanActivity.this, RiwayatTransaksiActivity.class);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        });

        // Aksi klik ke halaman Belanja (BARU DITAMBAHKAN)
        navBelanja.setOnClickListener(v -> {
            Intent intent = new Intent(PengaturanActivity.this, TransaksiActivity.class);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        });

        // Aksi klik ke halaman Produk
        navProduk.setOnClickListener(v -> {
            Intent intent = new Intent(PengaturanActivity.this, ProdukActivity.class);
            startActivity(intent);
            finish();
            overridePendingTransition(0, 0);
        });
        // ========================================================================

        // Logika tombol Keluar bawaan Anda
        TextView tvKeluar = findViewById(R.id.tvKeluar);
        tvKeluar.setOnClickListener(v -> {
            Toast.makeText(PengaturanActivity.this, "Berhasil Keluar", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(PengaturanActivity.this, LoginActivity.class);
            // Menghapus semua riwayat halaman dari memori HP agar tidak bisa di-back
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}