package com.example.cloudkasir;

import android.content.Context;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class ProdukAdapter extends RecyclerView.Adapter<ProdukAdapter.ProdukViewHolder> {

    private Context context;
    private ArrayList<Produk> listProduk;

    public ProdukAdapter(Context context, ArrayList<Produk> listProduk) {
        this.context = context;
        this.listProduk = listProduk;
    }

    @NonNull
    @Override
    public ProdukViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_produk, parent, false);

        return new ProdukViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ProdukViewHolder holder, int position) {

        Produk produk = listProduk.get(position);

        holder.txtNama.setText(produk.getNama());
        holder.txtHarga.setText("Rp " + produk.getHarga());
        holder.txtStok.setText("Stok: " + produk.getStok());

        Glide.with(context)
                .load(produk.getFotoUrl())
                .placeholder(R.mipmap.ic_launcher)
                .into(holder.imgFoto);

        holder.itemView.setOnClickListener(v -> {

            boolean ditemukan = false;

            for (KeranjangItem item : KeranjangManager.keranjang) {

                if (item.getNamaProduk().equals(produk.getNama())) {

                    item.setJumlah(item.getJumlah() + 1);

                    ditemukan = true;

                    Toast.makeText(
                            context,
                            produk.getNama() +
                                    " ditambahkan (" +
                                    item.getJumlah() + ")",
                            Toast.LENGTH_SHORT
                    ).show();

                    break;
                }
            }

            if (!ditemukan) {

                KeranjangManager.keranjang.add(
                        new KeranjangItem(
                                produk.getNama(),
                                produk.getHarga(),
                                1,
                                produk.getFotoUrl()
                        )
                );

                Toast.makeText(
                        context,
                        produk.getNama() + " ditambahkan",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listProduk.size();
    }

    public void updateList(ArrayList<Produk> newList) {
        this.listProduk = newList;
        notifyDataSetChanged();
    }

    public static class ProdukViewHolder extends RecyclerView.ViewHolder {

        ImageView imgFoto;
        TextView txtNama;
        TextView txtHarga;
        TextView txtStok;

        public ProdukViewHolder(@NonNull View itemView) {
            super(itemView);

            imgFoto = itemView.findViewById(R.id.imgFoto);
            txtNama = itemView.findViewById(R.id.txtNama);
            txtHarga = itemView.findViewById(R.id.txtHarga);
            txtStok = itemView.findViewById(R.id.txtStok);
        }
    }
}