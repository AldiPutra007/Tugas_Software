package com.example.cloudkasir;

public class KeranjangItem {
    private String namaProduk;
    private double harga;
    private int jumlah;
    private String fotoUrl; // 1. Variabel baru untuk menampung URL foto

    // 2. Pastikan di bagian ini (Constructor) menerima 4 parameter sesuai urutannya
    public KeranjangItem(String namaProduk, double harga, int jumlah, String fotoUrl) {
        this.namaProduk = namaProduk;
        this.harga = harga;
        this.jumlah = jumlah;
        this.fotoUrl = fotoUrl;
    }

    public String getNamaProduk() { return namaProduk; }
    public double getHarga() { return harga; }
    public int getJumlah() { return jumlah; }
    public void setJumlah(int jumlah) { this.jumlah = jumlah; }

    // 3. Pastikan Getter ini ada agar bisa dipanggil oleh Adapter nantinya
    public String getFotoUrl() { return fotoUrl; }
}