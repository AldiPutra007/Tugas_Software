package com.example.cloudkasir;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class TambahBarangActivity extends AppCompatActivity {

    private ImageView ivFotoBarang;
    private Uri imageUri;
    private Bitmap bitmapFoto; // Menyimpan foto dalam bentuk Bitmap untuk dikirim

    private static final String URL_TAMBAH_BARANG = "http://10.35.5.88/cloudkasir/tambah_barang.php";

    private final ActivityResultLauncher<Intent> galleryLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    imageUri = result.getData().getData();
                    try {
                        // Ubah URI gambar yang dipilih menjadi Bitmap
                        InputStream imageStream = getContentResolver().openInputStream(imageUri);
                        bitmapFoto = BitmapFactory.decodeStream(imageStream);

                        ivFotoBarang.setPadding(0, 0, 0, 0);
                        ivFotoBarang.setImageBitmap(bitmapFoto);
                    } catch (Exception e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Gagal memuat gambar", Toast.LENGTH_SHORT).show();
                    }
                }
            }
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_barang);

        ivFotoBarang = findViewById(R.id.ivFotoBarang);
        Button btnSimpan = findViewById(R.id.btnSimpanBarang);
        EditText etNamaBarang = findViewById(R.id.etNamaBarang);
        EditText etHargaBarang = findViewById(R.id.etHargaBarang);
        EditText etStokBarang = findViewById(R.id.etStokBarang);

        ivFotoBarang.setOnClickListener(v -> {
            Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            galleryLauncher.launch(intent);
        });

        btnSimpan.setOnClickListener(v -> {
            String nama = etNamaBarang.getText().toString().trim();
            String harga = etHargaBarang.getText().toString().trim();
            String stok = etStokBarang.getText().toString().trim();

            // Jika stok kosong, kita anggap 0
            if (stok.isEmpty()) {
                stok = "0";
            }

            if (nama.isEmpty() || harga.isEmpty()) {
                Toast.makeText(this, "Nama dan Harga harus diisi!", Toast.LENGTH_SHORT).show();
            } else if (bitmapFoto == null) {
                Toast.makeText(this, "Silakan pilih foto terlebih dahulu", Toast.LENGTH_SHORT).show();
            } else {
                simpanKeDatabase(nama, harga, stok, bitmapFoto);
            }
        });
    }

    // Mengubah Bitmap menjadi teks (String Base64)
    private String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        // Compress gambar menjadi JPEG kualitas 70% agar tidak terlalu berat saat dikirim
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, baos);
        byte[] imageBytes = baos.toByteArray();
        return Base64.encodeToString(imageBytes, Base64.DEFAULT);
    }

    // Fungsi Volley untuk mengirim data ke PHP
    private void simpanKeDatabase(final String nama, final String harga, final String stok, Bitmap bitmap) {
        Toast.makeText(this, "Menyimpan barang...", Toast.LENGTH_SHORT).show();

        final String fotoBase64 = getStringImage(bitmap);

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL_TAMBAH_BARANG,
                response -> {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        String status = jsonObject.getString("status");
                        String message = jsonObject.getString("message");

                        if (status.equals("success")) {
                            Toast.makeText(TambahBarangActivity.this, "Berhasil: " + message, Toast.LENGTH_SHORT).show();

                            // Arahkan kembali ke halaman produk
                            Intent intent = new Intent(TambahBarangActivity.this, ProdukActivity.class);
                            startActivity(intent);
                            finish();
                        } else {
                            Toast.makeText(TambahBarangActivity.this, "Gagal: " + message, Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(TambahBarangActivity.this, "Error JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(TambahBarangActivity.this, "Gagal koneksi ke server!", Toast.LENGTH_SHORT).show();
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nama", nama);
                params.put("harga", harga);
                params.put("stok", stok);
                params.put("foto", fotoBase64); // Kirim gambar dalam bentuk teks panjang
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}