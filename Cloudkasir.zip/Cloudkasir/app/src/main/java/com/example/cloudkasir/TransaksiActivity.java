package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class TransaksiActivity extends AppCompatActivity {

    private ImageView btnBack;
    private ImageView btnClear;
    private EditText etSearch;
    private RecyclerView rvKeranjang;
    private TextView tvTotalItem;
    private TextView tvTotalPrice;
    private MaterialButton btnBayar;

    private List<KeranjangItem> keranjangList;
    private KeranjangAdapter adapter;

    private double totalHargaKeseluruhan = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaksi);

        btnBack = findViewById(R.id.btnBack);
        btnClear = findViewById(R.id.btnClear);
        etSearch = findViewById(R.id.etSearch);
        rvKeranjang = findViewById(R.id.rvKeranjang);
        tvTotalItem = findViewById(R.id.tvTotalItem);
        tvTotalPrice = findViewById(R.id.tvTotalPrice);
        btnBayar = findViewById(R.id.btnBayar);

        // Ambil data dari keranjang global
        keranjangList = KeranjangManager.keranjang;

        rvKeranjang.setLayoutManager(
                new LinearLayoutManager(this)
        );

        adapter = new KeranjangAdapter(
                keranjangList,
                this::hitungTotal
        );

        rvKeranjang.setAdapter(adapter);

        // Hitung total pertama kali
        hitungTotal();

        // Tombol kembali
        btnBack.setOnClickListener(v -> finish());

        // Tombol hapus keranjang
        btnClear.setOnClickListener(v -> {

            KeranjangManager.keranjang.clear();

            adapter.notifyDataSetChanged();

            hitungTotal();

            Toast.makeText(
                    this,
                    "Keranjang dikosongkan",
                    Toast.LENGTH_SHORT
            ).show();
        });

        // Pencarian manual
        etSearch.setOnEditorActionListener((v, actionId, event) -> {

            if (actionId == EditorInfo.IME_ACTION_SEARCH
                    || (event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) {

                String keyword =
                        etSearch.getText().toString().trim();

                if (!keyword.isEmpty()) {
                    cariDanTambahProduk(keyword);
                }

                return true;
            }

            return false;
        });

        // Tombol bayar
        btnBayar.setOnClickListener(v -> {

            if (keranjangList.isEmpty()) {

                Toast.makeText(
                        this,
                        "Keranjang masih kosong!",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            Intent intent =
                    new Intent(
                            TransaksiActivity.this,
                            PembayaranActivity.class
                    );

            intent.putExtra(
                    "TOTAL_HARGA",
                    totalHargaKeseluruhan
            );

            startActivity(intent);
        });
    }

    private void cariDanTambahProduk(String keyword) {

        String namaProduk = "";
        double hargaProduk = 0;
        String fotoProduk = "";

        if (keyword.equalsIgnoreCase("A")) {

            namaProduk = "Barang A";
            hargaProduk = 10000;

        } else if (keyword.equalsIgnoreCase("B")) {

            namaProduk = "Barang B";
            hargaProduk = 15000;

        } else {

            Toast.makeText(
                    this,
                    "Produk tidak ditemukan",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        boolean ditemukan = false;

        for (KeranjangItem item : keranjangList) {

            if (item.getNamaProduk().equals(namaProduk)) {

                item.setJumlah(
                        item.getJumlah() + 1
                );

                ditemukan = true;
                break;
            }
        }

        if (!ditemukan) {

            keranjangList.add(
                    new KeranjangItem(
                            namaProduk,
                            hargaProduk,
                            1,
                            fotoProduk
                    )
            );
        }

        adapter.notifyDataSetChanged();

        hitungTotal();

        etSearch.setText("");
    }

    private void hitungTotal() {

        int totalItem = 0;

        totalHargaKeseluruhan = 0;

        for (KeranjangItem item : keranjangList) {

            totalItem += item.getJumlah();

            totalHargaKeseluruhan +=
                    item.getHarga() *
                            item.getJumlah();
        }

        Locale localeID =
                new Locale("in", "ID");

        NumberFormat rupiah =
                NumberFormat.getCurrencyInstance(localeID);

        tvTotalItem.setText(
                "Total (" + totalItem + " item)"
        );

        tvTotalPrice.setText(
                rupiah.format(totalHargaKeseluruhan)
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        if (adapter != null) {
            adapter.notifyDataSetChanged();
        }

        hitungTotal();
    }
}