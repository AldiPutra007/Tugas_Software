package com.example.cloudkasir;

public class Produk {
    private String id;
    private String nama;
    private int harga;
    private int stok;
    private String fotoUrl;

    // Constructor untuk mengisi data
    public Produk(String id, String nama, int harga, int stok, String fotoUrl) {
        this.id = id;
        this.nama = nama;
        this.harga = harga;
        this.stok = stok;
        this.fotoUrl = fotoUrl;
    }

    // Getter untuk mengambil data di Adapter
    public String getId() { return id; }
    public String getNama() { return nama; }
    public int getHarga() { return harga; }
    public int getStok() { return stok; }
    public String getFotoUrl() { return fotoUrl; }
}