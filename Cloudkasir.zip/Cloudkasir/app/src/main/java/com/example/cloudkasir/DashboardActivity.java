package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;

import java.text.NumberFormat;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    // Deklarasi TextView untuk menampung data
    private TextView tvTotalPenjualan, tvTotalTransaksi, tvTotalProduk;

    // URL API Dashboard (Pastikan IP sesuai dengan laptop Anda)
    private static final String URL_DASHBOARD = "http://10.35.5.88/cloudkasir/tampil_dashboard.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        // 1. Hubungkan variabel Java dengan ID di XML
        tvTotalPenjualan = findViewById(R.id.tvTotalPenjualan);
        tvTotalTransaksi = findViewById(R.id.tvTotalTransaksi);
        tvTotalProduk = findViewById(R.id.tvTotalProduk);

        // 2. Tarik data dari database PostgreSQL
        muatDataDashboard();

        // 3. Setup Navigasi Bawah
        TextView navDashboard = findViewById(R.id.navDashboard);
        TextView navTransaksi = findViewById(R.id.navTransaksi);
        TextView navBelanja = findViewById(R.id.navBelanja);
        TextView navProduk = findViewById(R.id.navProduk);
        TextView navLainnya = findViewById(R.id.navLainnya);

        // Tandai Dashboard sebagai menu aktif (Warna Biru)
        navDashboard.setTextColor(getResources().getColor(android.R.color.holo_blue_dark));

        // Aksi Navigasi
        navTransaksi.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, RiwayatTransaksiActivity.class));
            overridePendingTransition(0, 0);
        });

        navBelanja.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, TransaksiActivity.class));
            overridePendingTransition(0, 0);
        });

        navProduk.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, ProdukActivity.class));
            overridePendingTransition(0, 0);
        });

        navLainnya.setOnClickListener(v -> {
            startActivity(new Intent(DashboardActivity.this, PengaturanActivity.class));
            overridePendingTransition(0, 0);
        });
    }

    // Fungsi mengambil data Dashboard via API menggunakan Volley
    private void muatDataDashboard() {
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, URL_DASHBOARD, null,
                response -> {
                    try {
                        // Ambil nilai dari JSON (Key harus sama persis dengan file PHP)
                        double penjualanHariIni = response.getDouble("penjualan_hari_ini");
                        int totalTransaksi = response.getInt("total_transaksi");
                        int totalProduk = response.getInt("total_produk");

                        // Format angka ke Rupiah
                        Locale localeID = new Locale("in", "ID");
                        NumberFormat formatRupiah = NumberFormat.getCurrencyInstance(localeID);

                        // Tampilkan ke layar (TextView)
                        tvTotalPenjualan.setText(formatRupiah.format(penjualanHariIni));
                        tvTotalTransaksi.setText(String.valueOf(totalTransaksi));
                        tvTotalProduk.setText(String.valueOf(totalProduk));

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(DashboardActivity.this, "Gagal memproses data dashboard", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    error.printStackTrace();
                    Toast.makeText(DashboardActivity.this, "Gagal terhubung ke server", Toast.LENGTH_SHORT).show();
                }
        );

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(request);
    }

    // Refresh data setiap kali user kembali ke halaman Dashboard
    @Override
    protected void onResume() {
        super.onResume();
        muatDataDashboard();
    }
}