package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

import java.text.NumberFormat;
import java.util.Locale;

public class TransaksiBerhasilActivity extends AppCompatActivity {

    private TextView tvStrukTotal;
    private TextView tvStrukMetode;
    private TextView tvStrukKembalian;

    private MaterialButton btnSelesai;
    private MaterialButton btnLihatStruk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sukses);

        tvStrukTotal = findViewById(R.id.tvStrukTotal);
        tvStrukMetode = findViewById(R.id.tvStrukMetode);
        tvStrukKembalian = findViewById(R.id.tvStrukKembalian);

        btnSelesai = findViewById(R.id.btnSelesai);
        btnLihatStruk = findViewById(R.id.btnLihatStruk);

        double totalHarga =
                getIntent().getDoubleExtra(
                        "TOTAL_HARGA",
                        0
                );

        String metode =
                getIntent().getStringExtra(
                        "METODE"
                );

        Locale localeID = new Locale("in", "ID");
        NumberFormat rupiah =
                NumberFormat.getCurrencyInstance(localeID);

        tvStrukTotal.setText(
                rupiah.format(totalHarga)
        );

        tvStrukMetode.setText(
                metode
        );

        // Kembalian hanya untuk tunai
        if ("Tunai".equals(metode)) {

            tvStrukKembalian.setText(
                    rupiah.format(0)
            );

        } else {

            tvStrukKembalian.setText(
                    "-"
            );
        }

        btnSelesai.setOnClickListener(v -> {

            Intent intent = new Intent(
                    TransaksiBerhasilActivity.this,
                    DashboardActivity.class
            );

            intent.setFlags(
                    Intent.FLAG_ACTIVITY_CLEAR_TOP |
                            Intent.FLAG_ACTIVITY_NEW_TASK
            );

            startActivity(intent);
            finish();
        });

        btnLihatStruk.setOnClickListener(v -> {

            android.widget.Toast.makeText(
                    this,
                    "Fitur Struk Akan Ditambahkan",
                    android.widget.Toast.LENGTH_SHORT
            ).show();
        });
    }
}