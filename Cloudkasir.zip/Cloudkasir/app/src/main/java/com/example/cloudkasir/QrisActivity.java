package com.example.cloudkasir;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;

// 3 Baris ini WAJIB ADA untuk menjalankan Retrofit
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class QrisActivity extends AppCompatActivity {

    private MaterialButton btnSelesai;
    private double totalHarga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.qris);

        btnSelesai = findViewById(R.id.btnSelesai);

        // Ambil data harga dari Intent
        totalHarga = getIntent().getDoubleExtra("TOTAL_HARGA", 0);

        btnSelesai.setOnClickListener(v -> {
            // Jalankan fungsi API/Database
            simpanTransaksiQris(totalHarga);
        });
    }

    // Fungsi untuk mengirim data ke Database/API
    private void simpanTransaksiQris(double total) {
        // Matikan tombol sementara agar tidak double click
        btnSelesai.setEnabled(false);
        btnSelesai.setText("Memproses...");

        // INI KODE ASLI RETROFIT YANG SUDAH DINYALAKAN:
        ApiService apiService = ApiClient.getClient().create(ApiService.class);
        Call<ResponseModel> call = apiService.simpanTransaksi(total, "QRIS");

        call.enqueue(new Callback<ResponseModel>() {
            @Override
            public void onResponse(Call<ResponseModel> call, Response<ResponseModel> response) {
                btnSelesai.setEnabled(true);

                if (response.isSuccessful() && response.body() != null) {
                    String status = response.body().getStatus();

                    if (status.equals("sukses")) {
                        // JIKA BERHASIL MASUK DATABASE POSTGRESQL, BARU PINDAH HALAMAN
                        pindahKeHalamanBerhasil();
                    } else {
                        Toast.makeText(QrisActivity.this, response.body().getPesan(), Toast.LENGTH_SHORT).show();
                        btnSelesai.setText("Selesai");
                    }
                } else {
                    Toast.makeText(QrisActivity.this, "Gagal terhubung ke server PHP", Toast.LENGTH_SHORT).show();
                    btnSelesai.setText("Selesai");
                }
            }

            @Override
            public void onFailure(Call<ResponseModel> call, Throwable t) {
                btnSelesai.setEnabled(true);
                Toast.makeText(QrisActivity.this, "Error koneksi: " + t.getMessage(), Toast.LENGTH_LONG).show();
                btnSelesai.setText("Selesai");
            }
        });
    }

    // Fungsi ini HANYA dipanggil jika API merespon sukses
    private void pindahKeHalamanBerhasil() {
        // Hapus keranjang di sini, setelah data dipastikan masuk ke database
        KeranjangManager.keranjang.clear();

        Intent intent = new Intent(QrisActivity.this, TransaksiBerhasilActivity.class);
        intent.putExtra("TOTAL_HARGA", totalHarga);
        intent.putExtra("METODE", "QRIS");

        startActivity(intent);
        finish(); // Tutup activity QRIS
    }
}