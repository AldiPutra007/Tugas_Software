package com.example.cloudkasir;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiService {
    @FormUrlEncoded
    @POST("simpan_transaksi.php") // Nama file PHP ditaruh di sini
    Call<ResponseModel> simpanTransaksi(
            @Field("total_pembelian") double totalPembelian,
            @Field("metode_pembayaran") String metodePembayaran
    );
}